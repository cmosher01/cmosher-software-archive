// remoteDlg.cpp : implementation file
//

#include "stdafx.h"
#include "remote.h"
#include "remoteDlg.h"
#include "Timer.h"
#include "Parser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRemoteDlg dialog

CRemoteDlg::CRemoteDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRemoteDlg::IDD, pParent), m_com(1)
{
	//{{AFX_DATA_INIT(CRemoteDlg)
	m_strProduct = _T("");
	m_strCommand = _T("");
	m_nMaxSig = 2020;
	m_nMaxSht = 1035;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRemoteDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRemoteDlg)
	DDX_Text(pDX, IDC_TITLE, m_strProduct);
	DDX_Text(pDX, IDC_COMMAND, m_strCommand);
	DDX_Text(pDX, IDC_MAXSIG, m_nMaxSig);
	DDX_Text(pDX, IDC_MAXSHT, m_nMaxSht);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRemoteDlg, CDialog)
	//{{AFX_MSG_MAP(CRemoteDlg)
	ON_BN_CLICKED(IDC_RECORD, OnRecord)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRemoteDlg message handlers

BOOL CRemoteDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_com.Open();

	CString str;
	LPTSTR sApp = str.GetBuffer(MAX_PATH+1);
	::GetModuleFileName(NULL,sApp,MAX_PATH+1);
	str.ReleaseBuffer();

	TCHAR drive[_MAX_DRIVE];
	TCHAR dir[_MAX_DIR];
	TCHAR fname[_MAX_FNAME];
	TCHAR ext[_MAX_EXT];
	_tsplitpath(str,drive,dir,fname,ext);

	m_strLogFile = drive;
	m_strLogFile += dir;
	m_strLogFile += fname;
	m_strIniFile = m_strLogFile;

	m_strLogFile += ".LOG";
	m_strIniFile += ".INI";

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRemoteDlg::OnRecord() 
{
	try
	{
		DoRecord();
	}
	catch (const char* s)
	{
		HandleError(s);
	}
	catch (const CString& s)
	{
		HandleError(s);
	}
	CDialog::OnOK();
}

void CRemoteDlg::HandleError(const CString& str) 
{
	CString s;
	s.Format("The following error has occurred: %s.",(LPCTSTR)str);
	AfxMessageBox(s);
}

void CRemoteDlg::DoRecord() 
{
	CStdioFile f(m_strLogFile,CFile::modeCreate|CFile::modeWrite|CFile::modeNoTruncate);
	f.SeekToEnd();
	CParser parser;

	BOOL bEverGotAPulse(FALSE);
	BOOL bWasPulse = m_com.IsPulse();
	CTimer timer;
	while (timer.Peek()<3000000 || !bEverGotAPulse)
	{
		BOOL bIsPulse = m_com.IsPulse();
		if (bIsPulse!=bWasPulse)
		{
			int uS = timer.Checkpoint();
			if (!bEverGotAPulse)
				bEverGotAPulse = TRUE;
			else
				parser.Add(bWasPulse,uS);
			bWasPulse = bIsPulse;
		}
	}
	UpdateData();
	CString str;
	str.Format("[%s]\n%s\n\n",
		(LPCTSTR)m_strProduct,
		(LPCTSTR)m_strCommand);
	f.WriteString(str);
	parser.SetParams(m_nMaxSig,m_nMaxSht,f);
	CString strCmd = parser.Parse();
	f.Flush();
	WriteCommandToIniFile(strCmd);
}

void CRemoteDlg::WriteCommandToIniFile(const CString& str)
{
	if (!::WritePrivateProfileString(
		m_strProduct,  // pointer to section name
		m_strCommand,  // pointer to key name
		str,   // pointer to string to add
		m_strIniFile  // pointer to initialization filename
	))
		throw "Couldn't write .INI file entry.";
}
