#pragma once

class CTimer
{
	double m_dCPuS;
	double m_dLastCheckpoint;

	double GetCount();

public:
	CTimer();
	virtual ~CTimer();
	int Checkpoint();
	int Peek();
};
