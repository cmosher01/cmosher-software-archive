#include "stdafx.h"
#include "Timer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static double li_to_d(LARGE_INTEGER i);

double li_to_d(LARGE_INTEGER i)
{
	return (double)i.HighPart*ULONG_MAX+i.LowPart;
}

CTimer::CTimer()
{
	LARGE_INTEGER li;
	if (!::QueryPerformanceFrequency(&li))
		throw "QueryPerformanceFrequency failed";

	m_dCPuS = li_to_d(li)/1000000;

	m_dLastCheckpoint = GetCount();
}

CTimer::~CTimer()
{
}

int CTimer::Checkpoint()
{
	double d = GetCount();

	double dC = d-m_dLastCheckpoint;
	m_dLastCheckpoint = d;
	return (int)(dC/m_dCPuS+.000001);
}

double CTimer::GetCount()
{
	LARGE_INTEGER li;
	if (!::QueryPerformanceCounter(&li))
		throw "QueryPerformanceCounter failed";

	return li_to_d(li);
}

int CTimer::Peek()
{
	double d = GetCount();

	double dC = d-m_dLastCheckpoint;
	return (int)(dC/m_dCPuS+.000001);
}
