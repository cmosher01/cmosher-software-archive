#include "stdafx.h"
#include "ComPort.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CComPort::CComPort(int nPort):
	m_hFile(INVALID_HANDLE_VALUE)
{
	m_strPortName.Format("COM%d",nPort);
}

CComPort::~CComPort()
{
	if (m_hFile!=INVALID_HANDLE_VALUE)
		::CloseHandle(m_hFile);
}

void CComPort::Open()
{
	m_hFile = ::CreateFile("COM1",GENERIC_READ,0,NULL,OPEN_EXISTING,0,NULL);
	if (m_hFile==INVALID_HANDLE_VALUE)
	{
		CString str;
		str.Format("Could not open the communications (serial) port: %s",(LPCTSTR)m_strPortName);
		throw str;
	}
}

BOOL CComPort::IsPulse()
{
	DWORD dwModemStatus;
	if (!::GetCommModemStatus(m_hFile,&dwModemStatus))
		throw "Could not get the serial port status";

	return (dwModemStatus&MS_RLSD_ON)!=MS_RLSD_ON;
}
